package com.journaldev.xmlparsing;

/**
 * Created by anupamchugh on 06/05/16.
 */
public class Country {

    String name;
    String capital;
    String id;


    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
